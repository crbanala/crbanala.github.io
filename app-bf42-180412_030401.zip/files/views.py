from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login, logout
from django.contrib.sessions.models import Session
from django.contrib.auth.models import User
import json
from math import sin, cos, sqrt, atan2, radians

from .models import Marker
from .MarkerAWSUpload import MarkerAWSUpload

@csrf_exempt
def register(request):
	if request.method == 'POST':
		try:
			reqdata = json.loads(request.body.decode("utf-8"))
			user = User(username = reqdata["email"])
			user.set_password(reqdata["password"])
			user.save()
			return JsonResponse({"statuscode": True})
		except:
			return JsonResponse({"statuscode": False})
	if request.method == 'GET':
		pass

@csrf_exempt
def user_login(request):
	if request.method == 'POST':
		try:
			reqdata = json.loads(request.body.decode("utf-8"))
			user = authenticate(username = reqdata["email"], password = reqdata["password"])
			if user:
				login(request, user)
				return JsonResponse({"statuscode": True,"key":request.session.session_key})
			return JsonResponse({"statuscode": False})
		except:
			return JsonResponse({"statuscode": False})

	if request.method == 'GET':
		pass

@csrf_exempt
def user_logout(request):
	logout(request)
	return JsonResponse({"status": True})


@csrf_exempt
def contentupload(request):
    if request.method == 'POST':
        try:
            reqdata = json.loads(request.body.decode("utf-8"))
            session_key = reqdata["key"]
            content = reqdata["content"]
            latitude = reqdata["latitude"]
            longitude = reqdata["longitude"]
            extension = reqdata["extension"]
            session = Session.objects.get(session_key=session_key)
            uid = session.get_decoded().get('_auth_user_id')
            user = User.objects.get(pk=uid)

            if user:
                markerawsupload = MarkerAWSUpload()
                markerawsupload.user = user
                markerawsupload.content = content
                markerawsupload.latitude = latitude
                markerawsupload.longitude = longitude
                markerawsupload.extension = extension
                response = markerawsupload.upload()
                return response
            return JsonResponse({"statuscode": False})
        except:
            return JsonResponse({"statuscode": False})

    if request.method == 'GET':
        pass




@csrf_exempt
def markerdownload(request):
    if request.method == 'GET':
        print(request)
        try:
            # reqdata = json.loads(request.body.decode("utf-8"))
            reqdata = request.META
            session_key = reqdata["HTTP_KEY"]
            ulatitude = reqdata["HTTP_LATITUDE"]
            ulongitude = reqdata["HTTP_LONGITUDE"]
            session = Session.objects.get(session_key=session_key)
            uid = session.get_decoded().get('_auth_user_id')
            user = User.objects.get(pk=uid)
            if user:
                data = {}
                gpspairs = set()
                markerset = Marker.objects.all()
                for marker in markerset:
                    gpspair = (marker.latitude,marker.longitude)
                    gpspairs.add(gpspair)
                n = 0
                nResults = []
                for gpspair in gpspairs:
                    gpslat = gpspair[0]
                    gpslon = gpspair[1]
                    R = 6373.0
                    lat1 = radians(gpslat)
                    lon1 = radians(gpslon)
                    lat2 = radians(float(ulatitude))
                    lon2 = radians(float(ulongitude))
                    dlon = lon2 - lon1
                    dlat = lat2 - lat1
                    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
                    c = 2 * atan2(sqrt(a), sqrt(1 - a))
                    distance = R * c
                    print("Result:", distance)
                    if(distance<=5):
                        n = n+1
                        nResults.append({"lat": gpspair[0], "lon": gpspair[1]})
                data['nResults'] = n
                data['results'] = nResults
                data['statuscode'] = True
                return JsonResponse(data)
            else:
                return JsonResponse({"statuscode": False})
        except:
            return JsonResponse({"statuscode": False})

    if request.method == 'GET':
        pass
