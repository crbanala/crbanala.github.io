from django.views.generic.base import TemplateView
# from files.views import FilePolicyAPI
from django.conf.urls import url
from . import views

urlpatterns = [
	url(r'^register/$', views.register),
	url(r'^login/$', views.user_login),
	url(r'^logout/$', views.user_logout),
	url(r'^contentupload/$', views.contentupload),
	url(r'^markerdownload/$', views.markerdownload),
]

# urlpatterns += [
#     url(r'^upload/$', TemplateView.as_view(template_name='upload.html'), name='upload-home'),
#     url(r'^api/files/policy/$', FilePolicyAPI.as_view(), name='upload-policy'),
# ]
