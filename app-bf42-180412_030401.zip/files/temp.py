from __future__ import print_function
import base64
from django.http import JsonResponse
import subprocess
import boto
import boto.s3
import sys
from boto.s3.key import Key
from boto.s3.connection import OrdinaryCallingFormat

from .config_aws import (
    AWS_UPLOAD_BUCKET,
    AWS_UPLOAD_REGION,
    AWS_UPLOAD_ACCESS_KEY_ID,
    AWS_UPLOAD_SECRET_KEY
)


from .models import FileItem
from .models import Marker


class MarkerAWSUpload():
    user = None
    content = None
    extension = None
    latitude = None
    longitude = None

    def upload(self):
        print("____________________1")
        username_str = str(self.user.username)
        """
        Below we create the Django object. We'll use this
        in our upload path to AWS. 

        Example:
        To-be-uploaded file's name: Some Random File.mp4
        Eventual Path on S3: <bucket>/username/2312/2312.mp4
        """
        markerset = Marker.objects.all()
        marker_obj_id = len(markerset)+1
        print("____________________2")
        # marker_obj_id = marker_obj.id
        upload_start_path = "{username}/".format(
                    username = username_str
            )
        filename_final = "{file_obj_id}.mp4".format(
                    file_obj_id= marker_obj_id
                )
        filename_public = upload_start_path+filename_final
        testfile =''
        PUBLIC_URL = 's3-'+AWS_UPLOAD_REGION+'.amazonaws.com/'+AWS_UPLOAD_BUCKET+'/'+filename_public
        bucket_name = AWS_UPLOAD_BUCKET
        conn = boto.s3.connect_to_region(
                AWS_UPLOAD_REGION,
                aws_access_key_id=AWS_UPLOAD_ACCESS_KEY_ID,
                aws_secret_access_key=AWS_UPLOAD_SECRET_KEY,
                is_secure=True,
                calling_format=OrdinaryCallingFormat()
            )
        print("____________________3")
        bucket = conn.get_bucket(bucket_name)

        command = ''
        PUBLIC_URL = 's3-' + AWS_UPLOAD_REGION + '.amazonaws.com/' + AWS_UPLOAD_BUCKET + '/' + self.content
        filenameextension = str("imageToSave." + str(self.extension))
        # mp4 flv avi 3gb ogg
        if (self.extension != 'mp4' and self.extension != 'flv' and self.extension != 'avi' and self.extension != '3gb' and self.extension != 'ogg'):
            fh = open(filenameextension, "wb")
            fh.write(base64.b64decode(self.content))
            fh.close()
            print("____________________4")
            if (self.extension != 'gif'):
                # with open(filenameextension, 'r+b') as f:
                #     with Image.open(f) as image:
                #         # cover = resizeimage.resize_cover(image, [200, 100])
                #         fw = int(image.size[0] / 2)
                #         fhe = int(image.size[1] / 2)
                #         fw = fw - fw % 4;
                #         fhe = fhe - fhe % 4;
                #         print(fw);
                #         print(fhe);
                #         # cover = image.resize((fw, fhe), Image.ANTIALIAS)
                #         cover = resizeimage.resize_cover(image, [fw, fhe])
                #         cover.save(filenameextension, image.format)
                command ='/usr/local/bin/ffmpeg/ffmpeg-git-20180314-64bit-static/ffmpeg -loop 1 -i '
                command+=filenameextension+' -c:v libx264 -t 1 -pix_fmt yuv420p out.mp4'

                # command = '/usr/local/bin/ffmpeg/ffmpeg-git-20180314-64bit-static/ffmpeg ';
                # # command+= '-r 1/1 ';
                # command+= '-i '+filenameextension;
                # command+= ' -c:v libx264 ';
                # command+= '-crf 23 ';
                # command+= '-pix_fmt yuv420p ';
                # command += '-t 1 ';
                # command+= 'out.mp4';
                proc = subprocess.Popen(command,shell=True)  # check the ffmpeg command line :)
                proc.communicate()
                proc.wait()
                testfile = "out.mp4"
            else:
                command ='/usr/local/bin/ffmpeg/ffmpeg-git-20180314-64bit-static/ffmpeg ';
                command+='-i '+filenameextension
                command+=' -pix_fmt yuv420p out.mp4'
                proc = subprocess.Popen(command,shell=True)  # check the ffmpeg command line :)
                proc.communicate()
                proc.wait()
                testfile = "out.mp4"
        else:
            testfile = "out."+self.extension
            fh = open(testfile, "wb")
            fh.write(base64.b64decode(self.content))
            fh.close()

        print("____________________5")


        def percent_cb(complete, total):
            sys.stdout.write('.')
            sys.stdout.flush()
        k = Key(bucket)
        k.key = filename_public
        k.set_contents_from_filename(testfile,cb=percent_cb, num_cb=100)



        print("____________________8")
        command = 'rm '+testfile+';rm '+str(filenameextension)
        proc = subprocess.Popen(command,shell=True)  # check the ffmpeg command line :)
        proc.communicate()
        proc.wait()
        print("____________________9")

        marker_obj = Marker()
        marker_obj.user = self.user
        marker_obj.latitude = self.latitude
        marker_obj.longitude = self.longitude
        marker_obj.path = PUBLIC_URL
        marker_obj.save()
        return JsonResponse({"statuscode": True, "url": PUBLIC_URL})
        # return Response(data, status=status.HTTP_200_OK)